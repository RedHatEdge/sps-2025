{{/* vim: set filetype=mustache: */}}
{{/*
Expand the name of the chart.
*/}}
{{- define "dps-sse-mqtt-bridge.name" -}}
dps-sse-mqtt-bridge
{{- end -}}

{{- define "dps-sse-mqtt-mosquitto.name" -}}
dps-sse-mqtt-mosquitto
{{- end -}}



{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "dps-sse-mqtt-bridge.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Release.Name .Values.global.instancePrefix -}}
{{- printf "%s-%s" $name "sse-mqtt-bridge" | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "dps-sse-mqtt-bridge.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "dps-sse-mqtt-mosquitto.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Common labels bridge
*/}}
{{- define "dps-sse-mqtt-bridge.labels" -}}
{{ include "dps-sse-mqtt-bridge.selectorLabels" . }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
helm.sh/chart: {{ include "dps-sse-mqtt-bridge.chart" . }}
app.gec.io/prefix: {{ .Values.global.instancePrefix }}
app.gec.io/product: {{ .Values.global.instancePrefix }}-sse-mqtt-bridge
{{- end -}}

{{/*
Selector labels bridge
*/}}
{{- define "dps-sse-mqtt-bridge.selectorLabels" -}}
app.kubernetes.io/name: {{ include "dps-sse-mqtt-bridge.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}



{{/*
Common labels mosquitto
*/}}
{{- define "dps-sse-mqtt-mosquitto.labels" -}}
{{ include "dps-sse-mqtt-mosquitto.selectorLabels" . }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
helm.sh/chart: {{ include "dps-sse-mqtt-bridge.chart" . }}
app.gec.io/prefix: {{ .Values.global.instancePrefix }}
app.gec.io/product: {{ .Values.global.instancePrefix }}-sse-mqtt-mosquitto
{{- end -}}

{{/*
Selector labels mosquitto
*/}}
{{- define "dps-sse-mqtt-mosquitto.selectorLabels" -}}
app.kubernetes.io/name: {{ include "dps-sse-mqtt-mosquitto.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}

{{/*
Expand the name of the public sse-mqtt-bridge url
*/}}
{{- define "dps-sse-mqtt-bridge.hostname" -}}
{{- if .Values.global.basedomain -}}
{{ printf "%s.%s" (.Values.global.hostname | default .Release.Name) .Values.global.basedomain }}
{{- else -}}
{{ printf "%s.%s.%s.%s" .Release.Name .Values.global.instancePrefix .Release.Namespace "cluster.local" }}
{{- end -}}
{{- end -}}
