{{/*
Application prefix.
*/}}
{{- define "common.prefix" -}}
{{- .Values.global.instancePrefix -}}-cgw
{{- end }}

{{/*
Application basedomain.
*/}}
{{- define "common.basedomain" -}}
{{- .Values.global.basedomain -}}
{{- end }}

{{- define "catena-service.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Common labels.
*/}}
{{- define "common.labels" -}}
helm.sh/chart: {{ include "catena-service.name" . }}
app.gec.io/prefix: {{ .Values.global.instancePrefix }}
app.gec.io/product: {{ .Values.global.instancePrefix }}-cxgateway
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Backend labels.
*/}}
{{- define "common.backend.labels" -}}
app.gec.io/tier: backend
{{- end }}

{{/*
Frontend labels.
*/}}
{{- define "common.frontend.labels" -}}
app.gec.io/tier: frontend
{{- end }}

{{/*
Keycloak url.
*/}}
{{- define "keycloak.public.url" -}}
https://{{ .Values.global.hostname }}.{{ .Values.global.basedomain }}/keycloak
{{- end }}

{{/*
Keycloak url.
*/}}
{{- define "keycloak.internal.url" -}}
http://{{ .Values.global.instancePrefix }}-keycloak-keycloak-http:8080/keycloak
{{- end }}

{{/*
Common secret name.
*/}}
{{- define "common.secret" -}}
{{- .Values.global.instancePrefix -}}-common-secret
{{- end }}

{{/*
Common configmap name.
*/}}
{{- define "common.cm" -}}
{{- .Values.global.instancePrefix -}}-common
{{- end }}



{{/*
Postgres core service name.
*/}}
{{- define "postgres.service" -}}
{{ .Values.global.instancePrefix }}-{{ .Values.postgres.name }}-postgres
{{- end }}

{{/*
BPN (Business partner number) Value.
*/}}
{{- define "common.bpn" -}}
{{- .Values.common.bpn -}}
{{- end }}

{{/*
BPName (Business partner name) Value.
*/}}
{{- define "common.bpname" -}}
{{- .Values.common.bpname -}}
{{- end }}


{{/*
Participant Id ()
*/}}
{{- define "common.participantId" -}}
{{- printf "did:web:portal-backend.beta.cofinity-x.com:api:administration:staticdata:did:%s" .Values.common.bpn -}}
{{- end }}


{{/*
Common init container for pods using postgresql.
*/}}
{{- define "common.wait-for-postgresql" -}}
- name: wait-for-postgresql
  image: "{{ .Values.global.image.registry }}/{{ .Values.image.postgresPingImage.repository }}:{{ .Values.image.postgresPingImage.tag }}"
  imagePullPolicy: {{ .Values.global.image.pullPolicy }}
  securityContext:
    {{- toYaml .Values.common.securityContext | nindent 4 }}
  command: ["/bin/bash", "-c", "until psql -U ${user} -h ${host} -p ${port} ${dbname} -c 'select 1 as \"ready\"'; do echo 'Waiting for db to start ' ${dbname}; sleep 1; done"]
  env:
  - name: PGPASSWORD
    valueFrom:
      secretKeyRef:
        name: {{ .Values.postgres.databaseSecretNames.edc }}
        key: password
  envFrom:
  - secretRef:
      name: {{ .Values.postgres.databaseSecretNames.edc }}
  resources:
    {{- toYaml .Values.common.initResources.resources | nindent 4 }}
{{- end }}


{{/*
Common init container for pods using keycloak resources.
*/}}
{{- define "common.wait-for-keycloak" -}}
- name: wait-for-keycloak
  image: "{{ .Values.global.image.registry }}/{{ .Values.image.keycloakPingImage.repository }}:{{ .Values.image.keycloakPingImage.tag }}"
  imagePullPolicy: {{ .Values.global.image.pullPolicy }}
  securityContext:
    {{- toYaml .Values.common.securityContext | nindent 4 }}
  command: ['/bin/sh', '-c']
  args:
    - set -x;
      PUBLIC_KEY="";
      while [ true ];
      do
        PUBLIC_KEY=$(curl -Lks --max-time 3 {{ include "keycloak.internal.url" . }}/realms/{{ .Values.keycloak.realm }} | grep -o -E '"public_key":"[^"]+"' | awk -F ':' '{ print $2 }' | tr -d '"');
        if [ $? -eq 0 ];
        then
          if [ -n "$PUBLIC_KEY" ];
          then
            break;
          fi;
        fi;
        echo 'Unable to get public key from {{ include "keycloak.internal.url" . }}/realms/{{ .Values.keycloak.realm }}...';
        sleep 5;
      done;
      curl --max-time 3 -w "%{http_code}" -Lk -d "client_id=${CLIENT_ID}" -d "client_secret=${CLIENT_SECRET}" -d "grant_type=client_credentials" {{ include "keycloak.internal.url" . }}/realms/{{ .Values.keycloak.realm }}/protocol/openid-connect/token;
      if [ $(curl --max-time 3 -w "%{http_code}" -Lks -o /dev/null -d "client_id=${CLIENT_ID}" -d "client_secret=${CLIENT_SECRET}" -d "grant_type=client_credentials" {{ include "keycloak.internal.url" . }}/realms/{{ .Values.keycloak.realm }}/protocol/openid-connect/token) != "200" ];
      then
        echo 'Could not login at keycloak {{ include "keycloak.internal.url" . }}';
        exit 1;
      fi;
  envFrom:
  - secretRef:
      {{- if .Values.keycloak.saClientSecret }}
      name: {{ .Values.keycloak.saClientSecret }}
      {{- else }}
      name: keycloak-client-secret-{{ include "cx-gateway.name" . }}-sa
      {{- end }}
  resources:
    {{- toYaml .Values.common.initResources.resources | nindent 4 }}
{{- end }}


{{/*
Common init container for pods using openbao vault.
*/}}
{{- define "common.openbao-kv-init" -}}
{{- if .Values.edc_keyvault_init.enable }}
- name: openbao-kv-init
  imagePullPolicy: {{ .Values.global.image.pullPolicy }}
  image: "{{ .Values.global.image.registry }}/{{ .Values.edc_keyvault_init.image.repository }}:{{ .Values.edc_keyvault_init.image.tag }}"
  securityContext:
    {{- toYaml .Values.common.securityContext | nindent 4 }}
  env:
    - name: VAULT_ADDR
      value: "http://{{ template "openbao.fullname" . }}:8200"
    - name: VAULT_TOKEN
      valueFrom:
        secretKeyRef:
          name: {{ template "openbao.fullname" . }}-init-creds
          key: ROOTTOKEN
    - name: SECRET_ENGINE
      value: {{ .Values.vault.paths.secretEngine }}
    - name: DEMO_MODE
      value: "{{ .Values.common.demoMode.enabled }}"
    - name: DEMO_TYPE
      value: "{{ .Values.common.demoMode.type }}"
    - name: DATAPLANE_PRIVATE_KEY_ALIAS
      value: "{{ .Values.edc_dataplane.transfer.privatekeyAlias }}"
    - name: DATAPLANE_PUBLIC_KEY_ALIAS
      value: "{{ .Values.edc_dataplane.transfer.publickeyAlias }}"
    - name: AASREGISTRY_KEYCLOAK_CLIENT_SECRET
      valueFrom:
        secretKeyRef:
          name: keycloak-client-secret-{{ include "dtr.name" . }}-sa
          key: CLIENT_SECRET
    - name: CXGATEWAY_KEYCLOAK_CLIENT_SECRET
      valueFrom:
        secretKeyRef:
          name: keycloak-client-secret-{{ include "cx-gateway.name" . }}-sa
          key: CLIENT_SECRET
    - name: IATP_CLIENT_SECRET_ALIAS
      value: "{{ .Values.common.iatp.stsOauthClientSecretAlias }}"
    {{- if .Values.common.iatp.stsOauthClientSecret}}
    - name: IATP_CLIENT_SECRET
      value: "{{ .Values.common.iatp.stsOauthClientSecret }}"              
    {{- end }}
    {{- if .Values.common.demoMode.enabled  }}
    - name: MOCK_SERVER_KEYCLOAK_CLIENT_SECRET
      valueFrom:
        secretKeyRef:
          name: keycloak-client-secret-{{ .Values.global.instancePrefix }}-cgw-mock-sa-client
          key: CLIENT_SECRET
    {{- end }}          
  resources:
    requests:
      cpu: {{ .Values.edc_keyvault_init.resources.requests.cpu }}
      memory: {{ .Values.edc_keyvault_init.resources.requests.memory }}
    limits:
      cpu: {{ .Values.edc_keyvault_init.resources.limits.cpu }}
      memory: {{ .Values.edc_keyvault_init.resources.limits.memory }}
  volumeMounts:
    - mountPath: /tmp
      name: temp-dir
{{- end }}
{{- end }}



{{/*
Common template for different probes.
*/}}
{{- define "common.probe" -}}
{{ default "httpGet:" .probe }}
{{- if ne .probe "tcpSocket:" }}
  path: {{ .path | default "/" }}
{{- end }}
  port: {{ .port | default "default" }}
{{- if .failure }}
failureThreshold: {{ .failure }}
{{- end }}
{{- if .initial }}
initialDelaySeconds: {{ .initial }}
{{- end }}
{{- if .period }}
periodSeconds: {{ .period }}
{{- end }}
{{- if .timeout }}
timeoutSeconds: {{ .timeout }}
{{- end }}
{{- if .success }}
successThreshold: {{ .success }}
{{- end }}
{{- end }}