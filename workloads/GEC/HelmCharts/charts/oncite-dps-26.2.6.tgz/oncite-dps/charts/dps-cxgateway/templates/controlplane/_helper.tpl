{{/*
services name.
*/}}
{{- define "edc_controlplane.name" -}}
{{ include "common.prefix" . }}-controlplane
{{- end }}
