{{/*
services name.
*/}}
{{- define "edc_dataplane.name" -}}
{{ include "common.prefix" . }}-dataplane
{{- end }}
