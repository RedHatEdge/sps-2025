{{/*
services name.
*/}}
{{- define "cx-gateway.name" -}}
{{ include "common.prefix" . }}-gateway
{{- end }}


{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "smartmom-suite.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Release.Name .Values.global.instancePrefix -}}
{{- printf "%s-%s" $name "smartmom" | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
