{{/*
services name.
*/}}
{{- define "dtr.name" -}}
{{ include "common.prefix" . }}-dtr
{{- end }}