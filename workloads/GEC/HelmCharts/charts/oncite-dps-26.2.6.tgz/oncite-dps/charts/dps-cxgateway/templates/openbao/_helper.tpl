{{/*
Copyright (c) HashiCorp, Inc.
SPDX-License-Identifier: MPL-2.0
*/}}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to
this (by the DNS naming spec). If release name contains chart name it will
be used as a full name.
*/}}
{{- define "openbao.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{ include "common.prefix" . }}-vault
{{- end -}}
{{- end -}}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "openbao.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Expand the name of the chart.
*/}}
{{- define "openbao.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Allow the release namespace to be overridden
*/}}
{{- define "openbao.namespace" -}}
{{- default .Release.Namespace .Values.global.namespace -}}
{{- end -}}

{{/*
Compute if the server is enabled.
*/}}
{{- define "openbao.serverEnabled" -}}
{{- $_ := set . "serverEnabled" 
  (eq (.Values.vault.enable | toString) "true") -}}
{{- end -}}

{{/*
Compute if the server serviceaccount is enabled.
*/}}
{{- define "openbao.serverServiceAccountEnabled" -}}
{{- $_ := set . "serverServiceAccountEnabled" "true" -}}
{{- end -}}

{{/*
Compute if the server serviceaccount should have a token created and mounted to the serviceaccount.
*/}}
{{- define "openbao.serverServiceAccountSecretCreationEnabled" -}}
{{- $_ := set . "serverServiceAccountSecretCreationEnabled" "true" -}}
{{- end -}}

{{/*
Compute if the server service is enabled.
*/}}
{{- define "openbao.serverServiceEnabled" -}}
{{- template "openbao.serverEnabled" . -}}
{{- $_ := set . "serverServiceEnabled" .serverEnabled -}}
{{- end -}}

{{/*
Compute if the ui is enabled.
*/}}
{{- define "openbao.uiEnabled" -}}
{{- $_ := set . "uiEnabled" (or
  (eq (.Values.vault.ui.enable | toString) "true")
  (and (eq (.Values.vault.ui.enable | toString) "-") (eq (.Values.vault.enable | toString) "true"))) -}}
{{- end -}}

{{/*
Compute the maximum number of unavailable replicas for the PodDisruptionBudget.
This defaults to (n/2)-1 where n is the number of members of the server cluster.
Add a special case for replicas=1, where it should default to 0 as well.
*/}}
{{- define "openbao.pdb.maxUnavailable" -}}
{{- if eq (int .Values.vault.server.ha.replicas) 1 -}}
{{ 0 }}
{{- else if .Values.vault.server.ha.disruptionBudget.maxUnavailable -}}
{{ .Values.vault.server.ha.disruptionBudget.maxUnavailable -}}
{{- else -}}
{{- div (sub (div (mul (int .Values.vault.server.ha.replicas) 10) 2) 1) 10 -}}
{{- end -}}
{{- end -}}

{{/*
Resolve the external OpenBao/Vault address by checking global and injector values in order of precedence:
1. global.externalBaoAddr
2. global.externalVaultAddr 
*/}}

{{- define "openbao.externalAddr" -}}
  {{- if .Values.global.externalBaoAddr -}}
    {{- .Values.global.externalBaoAddr -}}
  {{- else -}}
    {{- .Values.global.externalVaultAddr -}}
  {{- end -}}
{{- end -}}

{{/*
Set the variable 'mode' to the server mode requested by the user to simplify
template logic.
*/}}
{{- define "openbao.mode" -}}
  {{- $_ := set . "mode" "standalone" -}}
{{- end -}}

{{/*
Set's the replica count based on the different modes configured by user
*/}}
{{- define "openbao.replicas" -}}
  {{ if eq .mode "standalone" }}
    {{- default 1 -}}
  {{ else if eq .mode "ha" }}
    {{- if or (kindIs "int64" .Values.vault.server.ha.replicas) (kindIs "float64" .Values.vault.server.ha.replicas) -}}
      {{- .Values.vault.server.ha.replicas -}}
    {{ else }}
      {{- 3 -}}
    {{- end -}}
  {{ else }}
    {{- default 1 -}}
  {{ end }}
{{- end -}}

{{/*
Set's up configmap mounts if this isn't a dev deployment and the user
defined a custom configuration.  Additionally iterates over any
extra volumes the user may have specified (such as a secret with TLS).
*/}}
{{- define "openbao.volumes" -}}
  {{- if and (ne .mode "dev") (or (.Values.vault.server.standalone.config) (.Values.vault.server.ha.config)) }}
        - name: config
          configMap:
            name: {{ template "openbao.fullname" . }}-config
  {{ end }}
  {{- range .Values.vault.server.extraVolumes }}
        - name: userconfig-{{ .name }}
          {{ .type }}:
          {{- if (eq .type "configMap") }}
            name: {{ .name }}
          {{- else if (eq .type "secret") }}
            secretName: {{ .name }}
          {{- end }}
            defaultMode: {{ .defaultMode | default 420 }}
  {{- end }}
  {{- if .Values.vault.server.volumes }}
    {{- toYaml .Values.vault.server.volumes | nindent 8}}
  {{- end }}
{{- end -}}

{{/*
Set's the args for custom command to render the OpenBao configuration
file with IP addresses to make the out of box experience easier
for users looking to use this chart with Consul Helm.
*/}}
{{- define "openbao.args" -}}
  {{ if or (eq .mode "standalone") (eq .mode "ha") }}
          - |
            cp /openbao/config/extraconfig-from-values.hcl /tmp/storageconfig.hcl;
            [ -n "${HOST_IP}" ] && sed -Ei "s|HOST_IP|${HOST_IP?}|g" /tmp/storageconfig.hcl;
            [ -n "${POD_IP}" ] && sed -Ei "s|POD_IP|${POD_IP?}|g" /tmp/storageconfig.hcl;
            [ -n "${HOSTNAME}" ] && sed -Ei "s|HOSTNAME|${HOSTNAME?}|g" /tmp/storageconfig.hcl;
            [ -n "${API_ADDR}" ] && sed -Ei "s|API_ADDR|${API_ADDR?}|g" /tmp/storageconfig.hcl;
            [ -n "${TRANSIT_ADDR}" ] && sed -Ei "s|TRANSIT_ADDR|${TRANSIT_ADDR?}|g" /tmp/storageconfig.hcl;
            [ -n "${RAFT_ADDR}" ] && sed -Ei "s|RAFT_ADDR|${RAFT_ADDR?}|g" /tmp/storageconfig.hcl;
            /usr/local/bin/docker-entrypoint.sh bao server -config=/tmp/storageconfig.hcl {{ .Values.vault.server.extraArgs }}
   {{ else if eq .mode "dev" }}
          - |
            /usr/local/bin/docker-entrypoint.sh bao server -dev {{ .Values.vault.server.extraArgs }}
  {{ end }}
{{- end -}}

{{/*
Set's additional environment variables based on the mode.
*/}}
{{- define "openbao.envs" -}}
  {{ if eq .mode "dev" }}
            - name: VAULT_DEV_ROOT_TOKEN_ID
              value: {{ .Values.vault.server.dev.devRootToken }}
            - name: VAULT_DEV_LISTEN_ADDRESS
              value: "[::]:8200"
  {{ end }}
{{- end -}}

{{/*
Set's which additional volumes should be mounted to the container
based on the mode configured.
*/}}
{{- define "openbao.mounts" -}}
  {{ if eq (.Values.vault.server.auditStorage.enabled | toString) "true" }}
            - name: audit
              mountPath: {{ .Values.vault.server.auditStorage.mountPath }}
  {{ end }}
  {{ if or (eq .mode "standalone") (and (eq .mode "ha") (eq (.Values.vault.server.ha.raft.enabled | toString) "true"))  }}
    {{ if eq (.Values.vault.server.dataStorage.enabled | toString) "true" }}
            - name: data
              mountPath: {{ .Values.vault.server.dataStorage.mountPath }}
    {{ end }}
  {{ end }}
  {{ if and (ne .mode "dev") (or (.Values.vault.server.standalone.config)  (.Values.vault.server.ha.config)) }}
            - name: config
              mountPath: /openbao/config
  {{ end }}
  {{- range .Values.vault.server.extraVolumes }}
            - name: userconfig-{{ .name }}
              readOnly: true
              mountPath: {{ .path | default "/openbao/userconfig" }}/{{ .name }}
  {{- end }}
  {{- if .Values.vault.server.volumeMounts }}
    {{- toYaml .Values.vault.server.volumeMounts | nindent 12}}
  {{- end }}
{{- end -}}

{{/*
Set's up the volumeClaimTemplates when data or audit storage is required.  HA
might not use data storage since Consul is likely it's backend, however, audit
storage might be desired by the user.
*/}}
{{- define "openbao.volumeclaims" -}}
  {{- if and (ne .mode "dev") (or .Values.vault.server.dataStorage.enabled .Values.vault.server.auditStorage.enabled) }}
  volumeClaimTemplates:
      {{- if and (eq (.Values.vault.server.dataStorage.enabled | toString) "true") (or (eq .mode "standalone") (eq (.Values.vault.server.ha.raft.enabled | toString ) "true" )) }}
    - metadata:
        name: data
        {{- include "openbao.dataVolumeClaim.annotations" . | nindent 6 }}
        {{- include "openbao.dataVolumeClaim.labels" . | nindent 6 }}
      spec:
        accessModes:
          - {{ .Values.vault.server.dataStorage.accessMode | default "ReadWriteOnce" }}
        resources:
          requests:
            storage: {{ .Values.vault.server.dataStorage.size }}
          {{- if .Values.vault.server.dataStorage.storageClass }}
        storageClassName: {{ .Values.vault.server.dataStorage.storageClass }}
          {{- end }}
      {{ end }}
      {{- if eq (.Values.vault.server.auditStorage.enabled | toString) "true" }}
    - metadata:
        name: audit
        {{- include "openbao.auditVolumeClaim.annotations" . | nindent 6 }}
        {{- include "openbao.auditVolumeClaim.labels" . | nindent 6 }}
      spec:
        accessModes:
          - {{ .Values.vault.server.auditStorage.accessMode | default "ReadWriteOnce" }}
        resources:
          requests:
            storage: {{ .Values.vault.server.auditStorage.size }}
          {{- if .Values.vault.server.auditStorage.storageClass }}
        storageClassName: {{ .Values.vault.server.auditStorage.storageClass }}
          {{- end }}
      {{ end }}
  {{ end }}
{{- end -}}

{{/*
Set's the affinity for pod placement when running in standalone and HA modes.
*/}}
{{- define "openbao.affinity" -}}
  {{- if and (ne .mode "dev") .Values.vault.server.affinity }}
      affinity:
        {{ $tp := typeOf .Values.vault.server.affinity }}
        {{- if eq $tp "string" }}
          {{- tpl .Values.vault.server.affinity . | nindent 8 | trim }}
        {{- else }}
          {{- toYaml .Values.vault.server.affinity | nindent 8 }}
        {{- end }}
  {{ end }}
{{- end -}}

{{/*
Sets the topologySpreadConstraints when running in standalone and HA modes.
*/}}
{{- define "openbao.topologySpreadConstraints" -}}
  {{- if and (ne .mode "dev") .Values.vault.server.topologySpreadConstraints }}
      topologySpreadConstraints:
        {{ $tp := typeOf .Values.vault.server.topologySpreadConstraints }}
        {{- if eq $tp "string" }}
          {{- tpl .Values.vault.server.topologySpreadConstraints . | nindent 8 | trim }}
        {{- else }}
          {{- toYaml .Values.vault.server.topologySpreadConstraints | nindent 8 }}
        {{- end }}
  {{ end }}
{{- end -}}


{{/*
Sets the toleration for pod placement when running in standalone and HA modes.
*/}}
{{- define "openbao.tolerations" -}}
  {{- if and (ne .mode "dev") .Values.vault.server.tolerations }}
      tolerations:
      {{- $tp := typeOf .Values.vault.server.tolerations }}
      {{- if eq $tp "string" }}
        {{ tpl .Values.vault.server.tolerations . | nindent 8 | trim }}
      {{- else }}
        {{- toYaml .Values.vault.server.tolerations | nindent 8 }}
      {{- end }}
  {{- end }}
{{- end -}}

{{/*
Set's the node selector for pod placement when running in standalone and HA modes.
*/}}
{{- define "openbao.nodeselector" -}}
  {{- if and (ne .mode "dev") .Values.vault.server.nodeSelector }}
      nodeSelector:
      {{- $tp := typeOf .Values.vault.server.nodeSelector }}
      {{- if eq $tp "string" }}
        {{ tpl .Values.vault.server.nodeSelector . | nindent 8 | trim }}
      {{- else }}
        {{- toYaml .Values.vault.server.nodeSelector | nindent 8 }}
      {{- end }}
  {{- end }}
{{- end -}}

{{/*
Sets extra pod annotations
*/}}
{{- define "openbao.annotations" }}
      annotations:
  {{- if .Values.vault.server.configAnnotation }}
        openbao.hashicorp.com/config-checksum: {{ include "openbao.config" . | sha256sum }}
  {{- end }}
  {{- if .Values.vault.server.annotations }}
        {{- $tp := typeOf .Values.vault.server.annotations }}
        {{- if eq $tp "string" }}
          {{- tpl .Values.vault.server.annotations . | nindent 8 }}
        {{- else }}
          {{- toYaml .Values.vault.server.annotations | nindent 8 }}
        {{- end }}
  {{- end }}
{{- end -}}

{{/*
securityContext for the statefulset pod template.
*/}}
{{- define "server.statefulSet.securityContext.pod" -}}
  {{- $dict := .Values.vault.server.statefulSet.securityContext.pod }}
  {{- $len := len $dict -}}
  {{- $os := (.Capabilities.APIVersions.Has "route.openshift.io/v1") -}}
  {{- $fs := hasKey $dict "fsGroup" }}
  {{- if or ( gt $len 0 ) ( eq $os false ) }}
  {{- default "securityContext:" | nindent 6 -}}
  {{- end -}}
  {{- if and ( eq $fs false ) ( eq $os false ) }}
  {{- default "fsGroup: 1000" | nindent 8 -}}
  {{- end }}
  {{- if ( gt $len 0 ) }}
  {{- toYaml .Values.vault.server.statefulSet.securityContext.pod | nindent 8 }}
  {{- end }}
{{- end -}}

{{/*
securityContext for the statefulset openbao container
*/}}
{{- define "server.statefulSet.securityContext.container" -}}
  {{- if .Values.vault.server.statefulSet.securityContext.container }}
          securityContext:
            {{- $tp := typeOf .Values.vault.server.statefulSet.securityContext.container }}
            {{- if eq $tp "string" }}
              {{- tpl .Values.vault.server.statefulSet.securityContext.container . | nindent 12 }}
            {{- else }}
              {{- toYaml .Values.vault.server.statefulSet.securityContext.container | nindent 12 }}
            {{- end }}
  {{- end }}
{{- end -}}

{{/*
Sets extra ui service annotations
*/}}
{{- define "openbao.ui.annotations" -}}
  {{- if .Values.vault.ui.annotations }}
  annotations:
    {{- $tp := typeOf .Values.vault.ui.annotations }}
    {{- if eq $tp "string" }}
      {{- tpl .Values.vault.ui.annotations . | nindent 4 }}
    {{- else }}
      {{- toYaml .Values.vault.ui.annotations | nindent 4 }}
    {{- end }}
  {{- end }}
{{- end -}}

{{/*
Create the name of the service account to use
*/}}
{{- define "openbao.serviceAccount.name" -}}
    {{ default (include "openbao.fullname" .) .Values.vault.server.serviceAccount.name }}
{{- end -}}

{{/*
Sets extra service account annotations
*/}}
{{- define "openbao.serviceAccount.annotations" -}}
  {{- if and (ne .mode "dev") .Values.vault.server.serviceAccount.annotations }}
  annotations:
    {{- $tp := typeOf .Values.vault.server.serviceAccount.annotations }}
    {{- if eq $tp "string" }}
      {{- tpl .Values.vault.server.serviceAccount.annotations . | nindent 4 }}
    {{- else }}
      {{- toYaml .Values.vault.server.serviceAccount.annotations | nindent 4 }}
    {{- end }}
  {{- end }}
{{- end -}}

{{/*
Sets extra ingress annotations
*/}}
{{- define "openbao.ingress.annotations" -}}
  {{- if .Values.vault.server.ingress.annotations }}
  annotations:
    {{- $tp := typeOf .Values.vault.server.ingress.annotations }}
    {{- if eq $tp "string" }}
      {{- tpl .Values.vault.server.ingress.annotations . | nindent 4 }}
    {{- else }}
      {{- toYaml .Values.vault.server.ingress.annotations | nindent 4 }}
    {{- end }}
  {{- end }}
{{- end -}}

{{/*
Sets extra route annotations
*/}}
{{- define "openbao.route.annotations" -}}
  {{- if .Values.vault.server.route.annotations }}
  annotations:
    {{- $tp := typeOf .Values.vault.server.route.annotations }}
    {{- if eq $tp "string" }}
      {{- tpl .Values.vault.server.route.annotations . | nindent 4 }}
    {{- else }}
      {{- toYaml .Values.vault.server.route.annotations | nindent 4 }}
    {{- end }}
  {{- end }}
{{- end -}}

{{/*
Sets extra openbao server Service annotations
*/}}
{{- define "openbao.service.annotations" -}}
  {{- if .Values.vault.server.service.annotations }}
    {{- $tp := typeOf .Values.vault.server.service.annotations }}
    {{- if eq $tp "string" }}
      {{- tpl .Values.vault.server.service.annotations . | nindent 4 }}
    {{- else }}
      {{- toYaml .Values.vault.server.service.annotations | nindent 4 }}
    {{- end }}
  {{- end }}
{{- end -}}

{{/*
Sets extra openbao server Service (active) annotations
*/}}
{{- define "openbao.service.active.annotations" -}}
  {{- if .Values.vault.server.service.active.annotations }}
    {{- $tp := typeOf .Values.vault.server.service.active.annotations }}
    {{- if eq $tp "string" }}
      {{- tpl .Values.vault.server.service.active.annotations . | nindent 4 }}
    {{- else }}
      {{- toYaml .Values.vault.server.service.active.annotations | nindent 4 }}
    {{- end }}
  {{- end }}
{{- end -}}
{{/*
Sets extra openbao server Service annotations
*/}}
{{- define "openbao.service.standby.annotations" -}}
  {{- if .Values.vault.server.service.standby.annotations }}
    {{- $tp := typeOf .Values.vault.server.service.standby.annotations }}
    {{- if eq $tp "string" }}
      {{- tpl .Values.vault.server.service.standby.annotations . | nindent 4 }}
    {{- else }}
      {{- toYaml .Values.vault.server.service.standby.annotations | nindent 4 }}
    {{- end }}
  {{- end }}
{{- end -}}

{{/*
Sets extra statefulset annotations
*/}}
{{- define "openbao.statefulSet.annotations" -}}
  {{- if .Values.vault.server.statefulSet.annotations }}
  annotations:
    {{- $tp := typeOf .Values.vault.server.statefulSet.annotations }}
    {{- if eq $tp "string" }}
      {{- tpl .Values.vault.server.statefulSet.annotations . | nindent 4 }}
    {{- else }}
      {{- toYaml .Values.vault.server.statefulSet.annotations | nindent 4 }}
    {{- end }}
  {{- end }}
{{- end -}}

{{/*
Sets VolumeClaim annotations for data volume
*/}}
{{- define "openbao.dataVolumeClaim.annotations" -}}
  {{- if and (ne .mode "dev") (.Values.vault.server.dataStorage.enabled) (.Values.vault.server.dataStorage.annotations) }}
  annotations:
    {{- $tp := typeOf .Values.vault.server.dataStorage.annotations }}
    {{- if eq $tp "string" }}
      {{- tpl .Values.vault.server.dataStorage.annotations . | nindent 4 }}
    {{- else }}
      {{- toYaml .Values.vault.server.dataStorage.annotations | nindent 4 }}
    {{- end }}
  {{- end }}
{{- end -}}

{{/*
Sets VolumeClaim labels for data volume
*/}}
{{- define "openbao.dataVolumeClaim.labels" -}}
  {{- if and (ne .mode "dev") (.Values.vault.server.dataStorage.enabled) (.Values.vault.server.dataStorage.labels) }}
  labels:
    {{- $tp := typeOf .Values.vault.server.dataStorage.labels }}
    {{- if eq $tp "string" }}
      {{- tpl .Values.vault.server.dataStorage.labels . | nindent 4 }}
    {{- else }}
      {{- toYaml .Values.vault.server.dataStorage.labels | nindent 4 }}
    {{- end }}
  {{- end }}
{{- end -}}

{{/*
Sets VolumeClaim annotations for audit volume
*/}}
{{- define "openbao.auditVolumeClaim.annotations" -}}
  {{- if and (ne .mode "dev") (.Values.vault.server.auditStorage.enabled) (.Values.vault.server.auditStorage.annotations) }}
  annotations:
    {{- $tp := typeOf .Values.vault.server.auditStorage.annotations }}
    {{- if eq $tp "string" }}
      {{- tpl .Values.vault.server.auditStorage.annotations . | nindent 4 }}
    {{- else }}
      {{- toYaml .Values.vault.server.auditStorage.annotations | nindent 4 }}
    {{- end }}
  {{- end }}
{{- end -}}

{{/*
Sets VolumeClaim labels for audit volume
*/}}
{{- define "openbao.auditVolumeClaim.labels" -}}
  {{- if and (ne .mode "dev") (.Values.vault.server.auditStorage.enabled) (.Values.vault.server.auditStorage.labels) }}
  labels:
    {{- $tp := typeOf .Values.vault.server.auditStorage.labels }}
    {{- if eq $tp "string" }}
      {{- tpl .Values.vault.server.auditStorage.labels . | nindent 4 }}
    {{- else }}
      {{- toYaml .Values.vault.server.auditStorage.labels | nindent 4 }}
    {{- end }}
  {{- end }}
{{- end -}}

{{/*
Set's the container resources if the user has set any.
*/}}
{{- define "openbao.resources" -}}
  {{- if .Values.vault.server.resources -}}
          resources:
{{ toYaml .Values.vault.server.resources | indent 12}}
  {{ end }}
{{- end -}}

{{/*
Inject extra environment vars in the format key:value, if populated
*/}}
{{- define "openbao.extraEnvironmentVars" -}}
{{- if .extraEnvironmentVars -}}
{{- range $key, $value := .extraEnvironmentVars }}
- name: {{ printf "%s" $key | replace "." "_" | upper | quote }}
  value: {{ $value | quote }}
{{- end }}
{{- end -}}
{{- end -}}

{{/*
Inject extra environment populated by secrets, if populated
*/}}
{{- define "openbao.extraSecretEnvironmentVars" -}}
{{- if .extraSecretEnvironmentVars -}}
{{- range .extraSecretEnvironmentVars }}
- name: {{ .envName }}
  valueFrom:
   secretKeyRef:
     name: {{ .secretName }}
     key: {{ .secretKey }}
{{- end -}}
{{- end -}}
{{- end -}}

{{/* Scheme for health check and local endpoint */}}
{{- define "openbao.scheme" -}}
{{ "http" }}
{{- end -}}

{{/*
imagePullSecrets generates pull secrets from either string or map values.
A map value must be indexable by the key 'name'.
*/}}
{{- define "imagePullSecrets" -}}
{{- with .Values.global.image.imagePullSecrets -}}
imagePullSecrets:
{{- range . -}}
{{- if typeIs "string" . }}
  - name: {{ . }}
{{- else if index . "name" }}
  - name: {{ .name }}
{{- end }}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
externalTrafficPolicy sets a Service's externalTrafficPolicy if applicable.
Supported inputs are Values.server.service and Values.ui
*/}}
{{- define "service.externalTrafficPolicy" -}}
{{- $type := "" -}}
{{- if .serviceType -}}
{{- $type = .serviceType -}}
{{- else if .type -}}
{{- $type = .type -}}
{{- end -}}
{{- if and .externalTrafficPolicy (or (eq $type "LoadBalancer") (eq $type "NodePort")) }}
  externalTrafficPolicy: {{ .externalTrafficPolicy }}
{{- else }}
{{- end }}
{{- end -}}

{{/*
loadBalancer configuration for the the UI service.
Supported inputs are Values.ui
*/}}
{{- define "service.loadBalancer" -}}
{{- if  eq (.serviceType | toString) "LoadBalancer" }}
{{- if .loadBalancerIP }}
  loadBalancerIP: {{ .loadBalancerIP }}
{{- end }}
{{- with .loadBalancerSourceRanges }}
  loadBalancerSourceRanges:
{{- range . }}
  - {{ . }}
{{- end }}
{{- end -}}
{{- end }}
{{- end -}}

{{/*
config file from values
*/}}
{{- define "openbao.config" -}}
  {{- if or (eq .mode "ha") (eq .mode "standalone") }}
  {{- $type := typeOf (index .Values.vault.server .mode).config }}
  {{- if eq $type "string" }}
  {{- if eq .mode "standalone" }}
    {{ tpl .Values.vault.server.standalone.config . | nindent 4 | trim }}
  {{- else if and (eq .mode "ha") (eq (.Values.vault.server.ha.raft.enabled | toString) "false") }}
    {{ tpl .Values.vault.server.ha.config . | nindent 4 | trim }}
  {{- else if and (eq .mode "ha") (eq (.Values.vault.server.ha.raft.enabled | toString) "true") }}
    {{ tpl .Values.vault.server.ha.raft.config . | nindent 4 | trim }}
  {{ end }}
  {{- else }}
  {{- if and (eq .mode "ha") (eq (.Values.vault.server.ha.raft.enabled | toString) "true") }}
{{ (index .Values.vault.server .mode).raft.config | toPrettyJson | indent 4 }}
  {{- else }}
{{ (index .Values.vault.server .mode).config | toPrettyJson | indent 4 }}
  {{- end }}
  {{- end }}
  {{- end }}
{{- end -}}
