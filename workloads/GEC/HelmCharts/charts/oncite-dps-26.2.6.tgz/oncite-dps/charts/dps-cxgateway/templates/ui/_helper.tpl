{{/*
services name.
*/}}
{{- define "cx_ui.name" -}}
{{ include "common.prefix" . }}-ui
{{- end }}
