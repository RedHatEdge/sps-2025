{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
*/}}

{{/*
Expand the name of the chart.
*/}}
{{- define "dps-workspace.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "dps-workspace.fullname" -}}
{{- $name := default .Release.Name .Values.global.instancePrefix -}}
{{- printf "%s-%s" $name "workspace" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "dps-workspace.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Common labels
*/}}
{{- define "dps-workspace.labels" -}}
helm.sh/chart: {{ include "dps-workspace.chart" . }}
{{ include "dps-workspace.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.gec.io/prefix: {{ .Values.global.instancePrefix }}
app.gec.io/product: {{ .Values.global.instancePrefix }}-workspace
app.gec.io/tier: frontend
{{- end }}

{{/*
Selector labels
*/}}
{{- define "dps-workspace.selectorLabels" -}}
app.kubernetes.io/name: {{ include "dps-workspace.name" . }}
app.kubernetes.io/release: {{ .Release.Name }}
{{- end }}

{{/*
Expand the name of public dps portal url
*/}}
{{- define "dps-workspace.hostname" -}}
{{- if .Values.global.basedomain -}}
{{ printf "%s.%s" (.Values.global.hostname | default .Release.Name) .Values.global.basedomain }}
{{- else -}}
{{ printf "%s.%s.%s.%s" .Release.Name .Values.global.instancePrefix .Release.Namespace "cluster.local" }}
{{- end -}}
{{- end -}}

{{/*
Expand the name of public dps portal url
*/}}
{{- define "dps-workspace.url" -}}
{{ printf "https://%s/workspace" (include "dps-workspace.hostname" .) }}
{{- end -}}

{{/*
Expand the name of the public keycloak url
*/}}
{{- define "dps-workspace.keycloak.url" -}}
{{- if .Values.keycloak.publicUrl -}}
{{ printf "%s" .Values.keycloak.publicUrl }}
{{- else -}}
{{ printf "https://%s/keycloak" (include "dps-workspace.hostname" .) }}
{{- end -}}
{{- end -}}

{{/*
Expand the name of public smartmom url
*/}}
{{- define "dps-workspace.smartmom.url" -}}
{{ printf "https://%s/core" (include "dps-workspace.hostname" .) }}
{{- end -}}

{{/*
Expand the name of public virtualfactory url
*/}}
{{- define "dps-workspace.virtualfactory.url" -}}
{{ printf "https://%s/virtualfactory" (include "dps-workspace.hostname" .) }}
{{- end -}}

{{/*
Expand the name of public oncitex url
*/}}
{{- define "dps-workspace.oncitex.url" -}}
{{ printf "https://%s/ai" (include "dps-workspace.hostname" .) }}
{{- end -}}