{{/*
Expand the name of the chart.
*/}}
{{- define "onlinehelp.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
*/}}
{{- define "onlinehelp.fullname" -}}
{{- $name := default .Release.Name .Values.global.instancePrefix -}}
{{- printf "%s-%s" $name "onlinehelp" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "onlinehelp.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Common labels
*/}}
{{- define "onlinehelp.labels" -}}
{{ include "onlinehelp.selectorLabels" . }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
helm.sh/chart: {{ include "onlinehelp.chart" . }}
app.gec.io/prefix: {{ .Values.global.instancePrefix }}
app.gec.io/product: {{ .Values.global.instancePrefix }}-onlinehelp
app.gec.io/tier: frontend
{{- end }}

{{/*
Selector labels
*/}}
{{- define "onlinehelp.selectorLabels" -}}
app.kubernetes.io/name: {{ include "onlinehelp.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}
