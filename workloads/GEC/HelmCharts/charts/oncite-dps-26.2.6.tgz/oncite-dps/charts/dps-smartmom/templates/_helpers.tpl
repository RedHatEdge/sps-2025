{{/* vim: set filetype=mustache: */}}
{{/*
Expand the name of the chart.
*/}}
{{- define "smartmom-suite.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "smartmom-suite.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Release.Name .Values.global.instancePrefix -}}
{{- printf "%s-%s" $name "smartmom" | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "smartmom-suite.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Common labels
*/}}
{{- define "smartmom-suite.labels" -}}
{{ include "smartmom-suite.selectorLabels" . }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
helm.sh/chart: {{ include "smartmom-suite.chart" . }}
app.gec.io/prefix: {{ .Values.global.instancePrefix }}
app.gec.io/product: {{ .Values.global.instancePrefix }}-smartmom
{{- end -}}

{{/*
Selector labels
*/}}
{{- define "smartmom-suite.selectorLabels" -}}
app.kubernetes.io/name: {{ include "smartmom-suite.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}

{{/*
Create the name of the service account to use
*/}}
{{- define "smartmom-suite.serviceAccountName" -}}
{{- if .Values.serviceAccount.create -}}
    {{ default (include "smartmom-suite.fullname" .) .Values.serviceAccount.name }}
{{- else -}}
    {{ default "default" .Values.serviceAccount.name }}
{{- end -}}
{{- end -}}

{{/*
Define version properties
*/}}
{{- define "smartmom-suite.versionProperties" -}}
{{- printf "smartmom.suite.version=%s\n" .Chart.Version  }}
{{- printf "smartmom.suite.buildtimestamp=%s\n" (.Files.Get "buildtimestamp") }}
{{- printf "smartmom.suite.deploytimestamp=%s\n" (now | date "2006-01-02T15:04:05+0000") }}
{{- end }}

{{/*
Expand the name of the public smartmom hostname
*/}}
{{- define "smartmom-suite.hostname" -}}
{{- if .Values.global.basedomain -}}
{{ printf "%s.%s" (.Values.global.hostname | default .Release.Name) .Values.global.basedomain }}
{{- else -}}
{{ printf "%s.%s.%s.%s" .Release.Name .Values.global.instancePrefix .Release.Namespace "cluster.local" }}
{{- end -}}
{{- end -}}

{{/*
Expand the name of the public smartmom url
*/}}
{{- define "smartmom-suite.url" -}}
{{ printf "https://%s%s" (include "smartmom-suite.hostname" .) "/core" }}
{{- end -}}

{{/*
Expand the name of the public keycloak url
*/}}
{{- define "smartmom-suite.keycloak.url" -}}
{{- if .Values.keycloak.publicUrl -}}
{{ printf "%s" .Values.keycloak.publicUrl }}
{{- else -}}
{{ printf "https://%s%s" (include "smartmom-suite.hostname" .) "/keycloak" }}
{{- end -}}
{{- end -}}

{{/*
Expand the name of the public workspace url
*/}}
{{- define "smartmom-suite.workspace.url" -}}
{{ printf "https://%s%s" (include "smartmom-suite.hostname" .) "/workspace" }}
{{- end -}}

{{/*
Expand the name of the kafka bootstrap service
*/}}
{{- define "smartmom-suite.kafkabootstrapserver" -}}
{{- if .Values.kafka.bootstrapServer -}}
{{ printf "%s" .Values.kafka.bootstrapServer }}
{{- else -}}
{{ printf "%s-%s-kafka-kafka-bootstrap:%s" .Values.global.instancePrefix .Values.kafka.name "9092" }}
{{- end -}}
{{- end -}}

{{/*
Expand the name of the kafka bootstrap service
*/}}
{{- define "smartmom-suite.bootstrapuser" -}}
{{ printf "%s-smartmom-bootstrap-user" .Values.global.instancePrefix }}
{{- end -}}

