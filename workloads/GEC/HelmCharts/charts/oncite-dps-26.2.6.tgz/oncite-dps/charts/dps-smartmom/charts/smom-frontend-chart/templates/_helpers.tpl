{{/*
Expand the prefix of the chart.
*/}}
{{- define "smom-frontend.prefix" -}}
{{- printf "%s-%s" .Values.global.instancePrefix "smartmom" -}}
{{- end }}

{{/*
Expand the name of the chart.
*/}}
{{- define "smom-frontend.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
*/}}
{{- define "smom-frontend.fullname" -}}
{{- printf "%s-%s" (include "smom-frontend.prefix" .) .Chart.Name | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "smom-frontend.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Common labels
*/}}
{{- define "smom-frontend.labels" -}}
{{ include "smom-frontend.selectorLabels" . }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/version: {{ .Values.image.tag | quote }}
helm.sh/chart: {{ include "smom-frontend.chart" . }}
app.gec.io/prefix: {{ .Values.global.instancePrefix }}
app.gec.io/product: {{ include "smom-frontend.prefix" . }}
app.gec.io/tier: frontend
{{- end }}

{{/*
Selector labels
*/}}
{{- define "smom-frontend.selectorLabels" -}}
app.kubernetes.io/name: {{ include "smom-frontend.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}
