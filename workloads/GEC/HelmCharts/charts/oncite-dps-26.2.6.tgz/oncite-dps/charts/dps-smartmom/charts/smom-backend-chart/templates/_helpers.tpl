{{/*
Expand the prefix of the chart.
*/}}
{{- define "smom-service.prefix" -}}
{{- printf "%s-%s" .Values.global.instancePrefix .Values.backendChartInfix -}}
{{- end }}

{{/*
Expand the name of the chart.
*/}}
{{- define "smom-service.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
*/}}
{{- define "smom-service.fullname" -}}
{{- printf "%s-%s" (include "smom-service.prefix" .) .Chart.Name  | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Determine database secret name
*/}}
{{- define "smom-service.dbsecretname" -}}
{{- if .Values.global.smartmom.databaseSecretName }}
{{- printf "%s" .Values.global.smartmom.databaseSecretName }}
{{- else }}
{{- printf "%s-%s-pguser-%s" (include "smom-service.prefix" .) .Values.postgres.name .Values.postgres.database.smartmom }}
{{- end }}
{{- end }}

{{/*
Determine service-config name
*/}}
{{- define "smom-service.serviceconfigname" -}}
{{- if .Values.serviceConfigName }}
{{- printf "%s" .Values.serviceConfigName }}
{{- else }}
{{- printf "%s-%s" (include "smom-service.prefix" .) "service-config" }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "smom-service.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Common labels
*/}}
{{- define "smom-service.labels" -}}
{{ include "smom-service.selectorLabels" . }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/version: {{ .Values.image.tag | quote }}
helm.sh/chart: {{ include "smom-service.chart" . }}
app.gec.io/prefix: {{ .Values.global.instancePrefix }}
app.gec.io/product: {{ include "smom-service.prefix" . }}
app.gec.io/tier: backend
{{- end }}

{{/*
Selector labels
*/}}
{{- define "smom-service.selectorLabels" -}}
app.kubernetes.io/name: {{ include "smom-service.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}
