{{/*
Expand the name of the chart.
*/}}
{{- define "hmi-client.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "hmi-client.fullname" -}}
{{- $name := default .Release.Name .Values.global.instancePrefix -}}
{{- printf "%s-%s" $name "hmiclient" | trunc 63 | trimSuffix "-" -}}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "hmi-client.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "hmi-client.labels" -}}
{{ include "hmi-client.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
helm.sh/chart: {{ include "hmi-client.chart" . }}
app.gec.io/prefix: {{ .Values.global.instancePrefix }}
app.gec.io/product: {{ .Values.global.instancePrefix }}-hmi-client
app.gec.io/tier: frontend
{{- end }}

{{/*
Selector labels
*/}}
{{- define "hmi-client.selectorLabels" -}}
app.kubernetes.io/name: {{ include "hmi-client.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}


{{/*
Create the name of the service account to use
*/}}
{{- define "hmi-client.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "hmi-client.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Expand public hmi-client hostname
*/}}
{{- define "hmi-client.hostname" -}}
{{- if .Values.global.basedomain -}}
{{ printf "%s.%s" (.Values.global.hostname | default .Release.Name) .Values.global.basedomain }}
{{- else -}}
{{ printf "%s.%s.%s.%s" .Release.Name .Values.global.instancePrefix .Release.Namespace "cluster.local" }}
{{- end -}}
{{- end -}}

{{/*
Expand the name of public hmi-client url
*/}}
{{- define "hmi-client.url" -}}
{{ printf "https://%s%s" (include "hmi-client.hostname" .) "/hmi" }}
{{- end -}}

{{/*
Expand the name of public smartmom url
*/}}
{{- define "hmi-client.smartmom.url" -}}
{{ printf "https://%s/core" (include "hmi-client.hostname" .) }}
{{- end -}}

{{/*
Expand the name of public keycloak url
*/}}
{{- define "hmi-client.keycloak.url" -}}
{{ printf "https://%s/keycloak" (include "hmi-client.hostname" .) }}
{{- end -}}

{{/*
Expand the name of public keycloak url
*/}}
{{- define "hmi-client.oncitex.url" -}}
{{ printf "https://%s/ai" (include "hmi-client.hostname" .) }}
{{- end -}}