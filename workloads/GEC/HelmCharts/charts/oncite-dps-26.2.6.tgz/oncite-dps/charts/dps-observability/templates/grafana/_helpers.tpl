{{/* vim: set filetype=mustache: */}}


{{/*
Expand the name of the public grafana url
*/}}
{{- define "dps-grafana.hostname" -}}
{{- if .Values.global.basedomain -}}
{{ printf "%s.%s" (.Values.global.hostname | default .Release.Name) .Values.global.basedomain }}
{{- else -}}
{{ printf "%s.%s.%s.%s" .Release.Name .Values.global.instancePrefix .Release.Namespace "cluster.local" }}
{{- end -}}
{{- end -}}
