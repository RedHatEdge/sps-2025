{{/* vim: set filetype=mustache: */}}
{{/*
Expand the name of the chart.
*/}}
{{- define "dps-observe.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "dps-observe.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Release.Name .Values.global.instancePrefix -}}
{{- printf "%s-%s" $name "observe" | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "dps-observe.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Common labels
*/}}
{{- define "dps-observe.labels" -}}
{{ include "dps-observe.selectorLabels" . }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
helm.sh/chart: {{ include "dps-observe.chart" . }}
app.gec.io/prefix: {{ .Values.global.instancePrefix }}
app.gec.io/product: {{ .Values.global.instancePrefix }}-observe
{{- end -}}

{{/*
Selector labels
*/}}
{{- define "dps-observe.selectorLabels" -}}
app.kubernetes.io/name: {{ include "dps-observe.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}