#!/bin/bash

# Array mit "namespace/deployment"-Kombinationen
DEPLOYMENTS=(
  "cgw-dev-customer/gec-keycloak-operator"
  "cgw-dev-supplier/gec-keycloak-operator"
  "cgw-saturn-customer/gec-keycloak-operator"
  "cgw-saturn-supplier/gec-keycloak-operator"
  "dps-observability-dev/gec-keycloak-operator"
  "gec-cluster-observability/gec-keycloak-operator"
  "great2know/gec-keycloak-operator"
  "oncite-dps-25-06/gec-keycloak-operator"
  "oncite-dps-25-10/gec-keycloak-operator"
  "oncite-dps-dev/gec-keycloak-operator"
  "oncite-dps-pentest-25-06/gec-keycloak-operator"
  "cgw-dev-supplier/apache-kafka-operator"
  "cgw-dev-supplier/dps-cgw-kafka-entity-operator"
  "dps-observability-dev/apache-kafka-operator"
  "dps-observability-dev/dps-infra-kafka-entity-operator"
  "great2know/apache-kafka-operator"
  "great2know/g2k-great2know-kafka-entity-operator"
  "oncite-dps-25-06/apache-kafka-operator"
  "oncite-dps-25-06/dps-infra-kafka-entity-operator"
  "oncite-dps-25-10/apache-kafka-operator"
  "oncite-dps-25-10/dps-infra-kafka-entity-operator"
  "oncite-dps-dev/apache-kafka-operator"
  "oncite-dps-dev/dps-infra-kafka-entity-operator"
  "oncite-dps-pentest-25-06/apache-kafka-operator"
  "oncite-dps-pentest-25-06/dps-infra-kafka-entity-operator"
  "alm-grafana/crunchy-postgres-operator"
  "cgw-dev-customer/crunchy-postgres-operator"
  "cgw-dev-supplier/crunchy-postgres-operator"
  "cgw-saturn-customer/crunchy-postgres-operator"
  "cgw-saturn-supplier/crunchy-postgres-operator"
  "dps-observability-dev/crunchy-postgres-operator"
  "gec-cluster-observability/crunchy-postgres-operator"
  "great2know/crunchy-postgres-operator"
  "oncite-dps-25-06/crunchy-postgres-operator"
  "oncite-dps-25-10/crunchy-postgres-operator"
  "oncite-dps-dev/crunchy-postgres-operator"
  "oncite-dps-pentest-25-06/crunchy-postgres-operator"
)

for d in "${DEPLOYMENTS[@]}"; do
  NAMESPACE="${d%%/*}"
  DEPLOYMENT="${d##*/}"
  kubectl scale deployment "$DEPLOYMENT" --replicas=1 -n "$NAMESPACE"
done


# oc get deployments -A \
#   | grep -iE ".*kafka.*operator" \
#   | awk '{print "  \"" $1 "/" $2 "\""}'

# oc get deployments -A \
#   | grep -iE ".*crunchy.*operator" \
#   | awk '{print "  \"" $1 "/" $2 "\""}'


#kubectl delete pod --all-namespaces --field-selector=status.phase=Failed
