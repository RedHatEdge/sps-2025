{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
*/}}

{{/*
Expand the name of the chart.
*/}}
{{- define "dps-ingress.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "dps-ingress.fullname" -}}
{{- $name := default .Release.Name .Values.global.instancePrefix -}}
{{- printf "%s-%s" $name "ingress" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "dps-ingress.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Common labels
*/}}
{{- define "dps-ingress.labels" -}}
helm.sh/chart: {{ include "dps-ingress.chart" . }}
{{ include "dps-ingress.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.gec.io/prefix: {{ .Values.global.instancePrefix }}
app.gec.io/product: {{ .Values.global.instancePrefix }}-ingress
app.gec.io/tier: gateway
{{- end }}

{{/*
Selector labels
*/}}
{{- define "dps-ingress.selectorLabels" -}}
app.kubernetes.io/name: {{ include "dps-ingress.name" . }}
app.kubernetes.io/release: {{ .Release.Name }}
{{- end }}

{{/*
Expand the name of public dps portal url
*/}}
{{- define "dps-ingress.hostname" -}}
{{- if .Values.global.basedomain -}}
{{ printf "%s.%s" (.Values.global.hostname | default .Release.Name) .Values.global.basedomain }}
{{- else -}}
{{ printf "%s.%s.%s.%s" .Release.Name .Values.global.instancePrefix .Release.Namespace "cluster.local" }}
{{- end -}}
{{- end -}}
