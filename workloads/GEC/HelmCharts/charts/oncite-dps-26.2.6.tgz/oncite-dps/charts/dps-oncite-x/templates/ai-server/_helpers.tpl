{{/*
Expand the name of the chart.
*/}}
{{- define "oncitex-ai-server.name" -}}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- printf "%s-%s" $name "oncitex-ai-server" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "oncitex-ai-server.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Values.global.instancePrefix "oncitex-ai-server" | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "oncitex-ai-server.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "oncitex-ai-server.labels" -}}
helm.sh/chart: {{ include "oncitex-ai-server.chart" . }}
{{ include "oncitex-ai-server.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "oncitex-ai-server.selectorLabels" -}}
app.kubernetes.io/name: {{ include "oncitex-ai-server.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "oncitex-ai-server.serviceAccountName" -}}
{{- if .Values.aiserver.serviceAccount.create }}
{{- default (include "oncitex-ai-server.fullname" .) .Values.aiserver.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.aiserver.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Determine database secret name
*/}}
{{- define "oncitex-ai-server.dbsecretname" -}}
{{- printf "%s" .Values.postgres.databaseSecretName }}
{{- end }}


