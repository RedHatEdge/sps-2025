{{/*
Expand the name of the chart.
*/}}
{{- define "oncitex-mcp-server.name" -}}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- printf "%s-%s" $name "oncitex-mcp-server" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "oncitex-mcp-server.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Values.global.instancePrefix "oncitex-mcp-server" | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "oncitex-mcp-server.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "oncitex-mcp-server.labels" -}}
helm.sh/chart: {{ include "oncitex-mcp-server.chart" . }}
{{ include "oncitex-mcp-server.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "oncitex-mcp-server.selectorLabels" -}}
app.kubernetes.io/name: {{ include "oncitex-mcp-server.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "oncitex-mcp-server.serviceAccountName" -}}
{{- if .Values.mcpserver.serviceAccount.create }}
{{- default (include "oncitex-mcp-server.fullname" .) .Values.mcpserver.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.mcpserver.serviceAccount.name }}
{{- end }}
{{- end }}
