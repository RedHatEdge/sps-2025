{{/*
Expand the name of the chart.
*/}}
{{- define "dashboard-mcp.name" -}}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- printf "%s-%s" $name "oncitex-dashboard-mcp-server" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "dashboard-mcp.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Values.global.instancePrefix "oncitex-dashboard-mcp-server" | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "dashboard-mcp.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "dashboard-mcp.labels" -}}
helm.sh/chart: {{ include "dashboard-mcp.chart" . }}
{{ include "dashboard-mcp.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "dashboard-mcp.selectorLabels" -}}
app.kubernetes.io/name: {{ include "dashboard-mcp.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "dashboard-mcp.serviceAccountName" -}}
{{- if .Values.dashboardmcp.serviceAccount.create }}
{{- default (include "dashboard-mcp.fullname" .) .Values.dashboardmcp.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.dashboardmcp.serviceAccount.name }}
{{- end }}
{{- end }}
