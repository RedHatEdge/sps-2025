{{/*
Expand the name of the chart.
*/}}
{{- define "cx-mcp.name" -}}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- printf "%s-%s" $name "oncitex-cx-mcp-server" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "cx-mcp.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Values.global.instancePrefix "oncitex-cx-mcp-server" | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "cx-mcp.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "cx-mcp.labels" -}}
helm.sh/chart: {{ include "cx-mcp.chart" . }}
{{ include "cx-mcp.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "cx-mcp.selectorLabels" -}}
app.kubernetes.io/name: {{ include "cx-mcp.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "cx-mcp.serviceAccountName" -}}
{{- if .Values.cxmcp.serviceAccount.create }}
{{- default (include "cx-mcp.fullname" .) .Values.cxmcp.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.cxmcp.serviceAccount.name }}
{{- end }}
{{- end }}
