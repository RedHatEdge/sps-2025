# ONCITE DPS Virtual Factory

This HelmChart is used to deploy virtual factory on OpenShift!
Edit ReadME
