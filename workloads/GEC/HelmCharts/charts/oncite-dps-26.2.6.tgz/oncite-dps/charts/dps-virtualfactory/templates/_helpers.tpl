
{{/*
Expand the name of the chart.
*/}}
{{- define "kafka" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "kafka.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name "virtualfactory" }}
{{- "virtualfactory" | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "virtualfactory-%s" $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "kafka.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "kafka.labels" -}}
helm.sh/chart: {{ include "kafka.chart" . }}
{{ include "kafka.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "kafka.selectorLabels" -}}
app.kubernetes.io/name: {{ include "kafka" . }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "kafka.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "kafka.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{- define "vf-service.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}


{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "vf-service.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Common labels
*/}}
{{- define "vf-common.labels" -}}
helm.sh/chart: {{ include "vf-service.chart" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.gec.io/prefix: {{ .Values.global.instancePrefix }}
app.gec.io/product: {{ .Values.global.instancePrefix }}-virtualfactory
{{- end -}}

{{- define "vf-core-service.labels" -}}
{{ include "vf-core-service.selectorLabels" . }}
{{ include "vf-common.labels" . }}
app.gec.io/tier: backend
{{- end -}}

{{- define "vf-core-service.selectorLabels" -}}
app.kubernetes.io/name: {{ .Values.global.instancePrefix }}-virtualfactory-core-service
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{- define "vf-smartmom-service.labels" -}}
{{ include "vf-smartmom-service.selectorLabels" . }}
{{ include "vf-common.labels" . }}
app.gec.io/tier: backend
{{- end -}}

{{- define "vf-smartmom-service.selectorLabels" -}}
app.kubernetes.io/name: {{ .Values.global.instancePrefix }}-virtualfactory-smartmom-service
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}

{{- define "vf-asset-service.labels" -}}
{{ include "vf-asset-service.selectorLabels" . }}
{{ include "vf-common.labels" . }}
app.gec.io/tier: backend
{{- end -}}

{{- define "vf-asset-service.selectorLabels" -}}
app.kubernetes.io/name: {{ .Values.global.instancePrefix }}-virtualfactory-asset-service
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}

{{- define "vf-frontend.labels" -}}
{{ include "vf-frontend.selectorLabels" . }}
{{ include "vf-common.labels" . }}
app.gec.io/tier: frontend
{{- end -}}

{{- define "vf-frontend.selectorLabels" -}}
app.kubernetes.io/name: {{ .Values.global.instancePrefix }}-virtualfactory-ui-frontend
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}

{{- define "vf-help.labels" -}}
{{ include "vf-help.selectorLabels" . }}
{{ include "vf-common.labels" . }}
app.gec.io/tier: frontend
{{- end -}}

{{- define "vf-help.selectorLabels" -}}
app.kubernetes.io/name: {{ .Values.global.instancePrefix }}-virtualfactory-help-frontend
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}


{{/*
Init container for pods using postgres resources.
*/}}
{{- define "vf.wait-for-postgresql" -}}
- name: wait-for-postgresql
  image: "{{ .Values.global.image.registry }}/{{ .Values.image.postgresPingImage.repository }}:{{ .Values.image.postgresPingImage.tag }}"
  imagePullPolicy: {{ .Values.global.image.pullPolicy }}
  securityContext:
    {{- toYaml .Values.common.securityContext | nindent 4 }}
  resources:
    {{- toYaml .Values.common.resources | nindent 4 }}
  command: ['/bin/sh', '-c']
  args:
  - until echo '' > /dev/tcp/${host}/${port};
    do
      echo "Cannot connect to database ${host}:${port}";
      sleep 5;
    done
  envFrom:
  - secretRef:
      name: {{ .Values.postgres.databaseSecretName }}
{{- end }}

{{/*
Init container for pods using kafka resources.
*/}}
{{- define "vf.wait-for-kafka" -}}
- name: wait-for-kafka
  image: "{{ .Values.global.image.registry }}/{{ .Values.image.kafkaPingImage.repository }}:{{ .Values.image.kafkaPingImage.tag }}"
  imagePullPolicy: {{ .Values.global.image.pullPolicy }}
  securityContext:
    {{- toYaml .Values.common.securityContext | nindent 4 }}
  resources:
    {{- toYaml .Values.common.resources | nindent 4 }}
  command: ['/bin/sh', '-c']
  args:
    - until echo '' > /dev/tcp/${KAFKA_BOOTSTRAP_SERVERS/:/\/};
      do
        echo "Cannot connect to kafka ${KAFKA_BOOTSTRAP_SERVERS}";
        sleep 5;
      done
  envFrom:
  - configMapRef:
      name: {{ .Values.global.instancePrefix }}-virtualfactory-service-config
{{- end }}

{{/*
Init container for pods using keycloak resources.
*/}}
{{- define "vf.wait-for-keycloak" -}}
- name: wait-for-keycloak
  image: "{{ .Values.global.image.registry }}/{{ .Values.image.keycloakPingImage.repository }}:{{ .Values.image.keycloakPingImage.tag }}"
  imagePullPolicy: {{ .Values.global.image.pullPolicy }}
  securityContext:
    {{- toYaml .Values.common.securityContext | nindent 4 }}
  resources:
    {{- toYaml .Values.common.resources | nindent 4 }}
  command: ['/bin/sh', '-c']
  args:
    - set -x;
      PUBLIC_KEY="";
      while [ true ];
      do
        PUBLIC_KEY=$(curl -Lks --max-time 3 ${KEYCLOAK_INTERNAL_URL}/realms/${KEYCLOAK_REALM} | grep -o -E '"public_key":"[^"]+"' | awk -F ':' '{print $2}' | tr -d '"');
        if [ $? -eq 0 ];
        then
          if [ -n "$PUBLIC_KEY" ];
          then
            break;
          fi;
        fi;
        echo "Unable to get public key from ${KEYCLOAK_INTERNAL_URL}/realms/${KEYCLOAK_REALM}...";
        sleep 5;
      done;
      curl --max-time 3 -w "%{http_code}" -Lk -d "client_id=${CLIENT_ID}" -d "client_secret=${CLIENT_SECRET}" -d "grant_type=client_credentials" ${KEYCLOAK_INTERNAL_URL}/realms/${KEYCLOAK_REALM}/protocol/openid-connect/token;
      if [ $(curl --max-time 3 -w "%{http_code}" -Lks -o /dev/null -d "client_id=${CLIENT_ID}" -d "client_secret=${CLIENT_SECRET}" -d "grant_type=client_credentials" ${KEYCLOAK_INTERNAL_URL}/realms/${KEYCLOAK_REALM}/protocol/openid-connect/token) != "200" ];
      then
        echo "Could not login at keycloak ${KEYCLOAK_INTERNAL_URL}";
        exit 1;
      fi;
  envFrom:
    - configMapRef:
        name: {{ .Values.global.instancePrefix }}-virtualfactory-service-config
    - secretRef:
        {{- if .Values.keycloak.secretKeyRef }}
        name: {{ .Values.keycloak.secretKeyRef }}
        {{- else }}
        name: keycloak-client-secret-{{ .Values.global.instancePrefix }}-virtualfactory-{{ .Values.keycloak.saClient }}
        {{- end }}
{{- end }}

