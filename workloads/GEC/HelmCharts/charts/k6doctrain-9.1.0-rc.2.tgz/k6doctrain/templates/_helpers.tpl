{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
*/}}

{{/*
Expand the name of the chart.
*/}}
{{- define "k6doctrain.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "k6doctrain.fullname" -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "k6doctrain.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Common labels
*/}}
{{- define "k6doctrain.labels" -}}
helm.sh/chart: {{ include "k6doctrain.chart" . }}
{{ include "k6doctrain.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.gec.io/prefix: {{ .Values.global.instancePrefix }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "k6doctrain.selectorLabels" -}}
app.kubernetes.io/name: {{ include "k6doctrain.name" . }}
app.kubernetes.io/release: {{ .Release.Name }}
{{- end }}


{{/*
Require and include a value
*/}}
{{- define "require" -}}
    {{- $scope := index . 0 -}}
    {{- $name := index . 1 -}}
    {{required (print "Missing required value: " $name) (index $scope "Values" $name)}}
{{- end}}