{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
*/}}

{{/*
Expand the name of the chart.
*/}}
{{- define "doctrain.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "doctrain.fullname" -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "doctrain.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Common labels
*/}}
{{- define "doctrain.labels" -}}
{{ include "doctrain.selectorLabels" . }}
app.kubernetes.io/version: {{ default .Chart.AppVersion .Values.image.tag | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
helm.sh/chart: {{ include "doctrain.chart" . }}
app.gec.io/prefix: {{ .Values.global.instancePrefix }}
app.gec.io/product: {{ .Values.global.instancePrefix }}-doctrain
{{- end }}

{{/*
Selector labels
*/}}
{{- define "doctrain.selectorLabels" -}}
app.kubernetes.io/name: {{ include "doctrain.name" . }}
app.kubernetes.io/release: {{ .Release.Name }}
{{- end }}


{{/*
Require and include a value
*/}}
{{- define "require" -}}
    {{- $scope := index . 0 -}}
    {{- $name := index . 1 -}}
    {{required (print "Missing required value: " $name) (index $scope "Values" $name)}}
{{- end}}